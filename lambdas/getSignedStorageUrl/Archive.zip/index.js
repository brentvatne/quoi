let AWS = require('aws-sdk');
let s3 = new aws.S3();
let docClient = new AWS.DynamoDB.DocumentClient();
let fetchUserAsync = require('./fetchUserAsync');
let uuid = require('uuid/v1');

exports.handler = async (event, context) => {
  let { uuid } = event.arguments.input;
  let user = await fetchUserAsync(uuid);
  if (!user) {
    throw new Error('Must provide a valid user id');
  } else {
    await throwIfUserBannedAsync(user.email);
  }

  let key = uuid();
  let params = {
    Bucket: 'quoi',
    Region: 'us-east-1',
    Key: key,
    ACL: 'public-read',
    Expires: 120,
  };

  let url = await new Promise((resolve, reject) => {
    s3.getSignedUrl('putObject', params, (err, url) => {
      if (err) {
        reject(err);
      } else {
        resolve(url);
      }
    });
  });

  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ url }),
    isBase64Encoded: false,
  };
};

async function throwIfUserBannedAsync(email) {
  let params = {
    TableName: 'UserBanTable',
    Key: {
      email,
    },
  };

  return new Promise((resolve, reject) => {
    docClient.get(params, (err, data) => {
      if (err) {
        reject('Unknown error');
      } else if (data.Item) {
        reject('User is banned');
      } else {
        resolve();
      }
    });
  });
}
